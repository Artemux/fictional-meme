/*
 * @author Vladimir Pavlov kolobokhtc@gmail.com
 */
var Menu =
{

		divID : null,
    firstElID : 1,
    pos: -1,
    prev: -1,
    page : 0,
    pages : 1,
    elID : 0,
    size : 9,
		current_size : 9,

    delay : 300,
		delayTm : null,
		chanDelay: 3000,
		chanTm : null,
		chanStr : '',

    playlist : null,
    qualities: [],

		quality_selected_index : -1,

		quality_switch_count : 0,

		saved_active_item_id : null,

    selectedClass : 'selected',
    unSelectedClass : 'unselected'

}

Menu.init = function( divID ){

	this.divID = divID;

}

Menu.Render = function(){
	this.SetQualities();
	this.SetQualityHtml();
	this.FirstPage();
	this.SetBreadcrumbs();
	this.RecountPages();
	this.SetPageHtml();
	this.SelectFirst();
}

Menu.QualityRender = function() {
	this.FirstPage();
	this.SetPageHtml();
	this.SelectFirst();
}

Menu.SetQualities = function() {

	var self = this;
	self.qualities = [];

	var menu_types = Data.getVideoType(Menu.GetItemId());
	if(menu_types == 'play_link') {
		var qualities = Data.getVideoExtendeds();
		// console.log(qualities);
		if (qualities.length <= 0) {
			return false;
		}

		qualities.forEach(function(item){

			if(self.qualities.indexOf(item.quality) == -1){
				self.qualities.push(item.quality);
			}

		});
		this.quality_switch_count = 0;
	  this.quality_selected_index = 0;
		console.log(this.qualities);
	}

}

Menu.getQualitySwitchCount = function() {
	return this.quality_switch_count;
}

Menu.getQualitiesSelectedIndex = function() {
		return this.quality_selected_index;
}

Menu.getQuality = function(index) {
	if(index >= 0 && index < this.qualities.length) {
		return this.qualities[index];
	}
}

Menu.GetQualities = function() {
	return Menu.qualities;
}

Menu.SetSavedActiveItemID = function(item_id){
	this.saved_active_item_id = item_id;
}

Menu.SetActiveItem = function(){
	if (this.saved_active_item_id){
		Menu.SetItemId(this.saved_active_item_id);
		this.saved_active_item_id = null;
	}
}

Menu.DoSwitch = function()
{
	if ( this.chanStr ){
		var chanNo = parseInt(this.chanStr);
		if ( this.playlist[chanNo-1] ){
			this.prev = this.pos;
			this.pos = chanNo-1;
			this.SetItemId(chanNo-1);
			//Channel.Play();
		}
		this.chanStr = "";
	}
	this.chanTm = null;
}

Menu.IsKeypress = function(){
	if (this.chanStr.length > 0){
		return true;
	} else {
		return false;
	}
}

Menu.KeypressBack = function( )
{
	if ( this.chanStr.length > 0){
		this.chanStr = this.chanStr.substring(0, this.chanStr.length - 1);
		if ( this.chanTm != null ){
			clearTimeout(this.chanTm);
		}
		this.chanTm = setTimeout("Menu.DoSwitch()", this.chanDelay);
		Popup.Show(this.chanStr, this.chanDelay);
	} else {
		Popup.Hide();
	}

}

Menu.Keypress = function( keyStr )
{
	this.chanStr += keyStr;
	if ( this.chanTm != null ){
		clearTimeout(this.chanTm);
	}
	this.chanTm = setTimeout("Menu.DoSwitch()", this.chanDelay);
	Popup.Show(this.chanStr, this.chanDelay);
}

Menu.Select = function()
{
	if ( this.prev > -1 ){
		var prevEl = this.page * this.size + this.prev;
		$('#n'+prevEl).removeClass(this.selectedClass)
		$('#n'+prevEl).addClass(this.unSelectedClass);
	}
	var curEl = this.page * this.size + this.pos;
	$('#n'+curEl).removeClass(this.unSelectedClass);
	$('#n'+curEl).addClass(this.selectedClass);

	if ( this.delayTm != null ){
		clearTimeout(this.delayTm);
	}

	this.ShowDetails();


}

Menu.ShowDetails = function(){

	var item = Data.getVideoExtended(Menu.GetItemId());

	if (item.image){
		$('.detail-block .detail-block-image img').attr('src',item.image).show();
	} else{
		$('.detail-block .detail-block-image img').hide();
	}

	if (item.info){
		$('.detail-block .detail-block-info').html(item.info).show();
	} else {
		$('.detail-block .detail-block-info').hide();
	}

	if (item.vote_negative){
		$('.detail-block .detail-block-vote-negative').text(item.vote_negative);
		$('.detail-block .detail-block-vote').show();
	} else {
		$('.detail-block .detail-block-vote').hide();
	}

	if (item.vote_positive){
		$('.detail-block .detail-block-vote-positive').text(item.vote_positive)
		$('.detail-block .detail-block-vote').show();
	} else {
		$('.detail-block .detail-block-vote').hide();
	}

	var menu_type = Data.getVideoType(Menu.GetItemId())

	if (menu_type == 'files' || menu_type == 'play_link'){
		$('.detail-block').hide();
	} else {
		$('.detail-block').show();
	}
}

Menu.SetList = function( list ){

	this.playlist = list;

	if ( Data.getVideoCount() > this.size ){
		this.pages = Math.ceil(Data.getVideoCount()/this.size);
	}

}

Menu.RecountPages = function() {
	//if ( Data.getVideoCount() > this.size ){
		this.pages = Math.ceil(Data.getVideoCount()/this.size);
	//}
}

Menu.SelectFirst = function()
{
	this.prev = this.pos;
	this.pos = 0;
	this.Select();
}

Menu.SelectLast = function()
{
	this.prev = this.pos;
	this.pos = this.size - 1;
	this.Select();
}

Menu.SelectNext = function()
{
	this.prev = this.pos;
	++this.pos;
	this.Select();
}

Menu.SelectPrev = function()
{
	this.prev = this.pos;
	--this.pos;
	this.Select();
}

Menu.nextQuality = function(){
		this.quality_switch_count++;
		var array_size = this.qualities.length;

		if(array_size <= 0){
			return false;
		}

		if (this.quality_selected_index < (array_size - 1)){
			this.quality_selected_index++;
		} else {
			this.quality_selected_index=0;
		}

}

Menu.ChangeQuality = function() {
	var quality = $('.quality_name').text();
	var innerHtml = '';
	if(quality) {
		for( var i = 0; i < this.size; i++) {
			//console.log(Channel.GetContainer((i+1)));
			var str = Channel.GetContainer((i+1));
			if(str.indexOf(quality) > -1) {
				innerHtml += str;
			}
		}
	}

	$('#'+this.divID).html(innerHtml);
}

Menu.clearRemoved = function() {
	Data.clearVideoExtendedsRemoved();
	Data.clearVideoNamesRemoved();
	Data.clearVideoTypesRemoved();
	Data.clearVideoURLsRemoved();
	Data.clearVideoImagesRemoved();
}

Menu.refillData = function() {
			var len = arguments.length;
			if(Data.videoExtendedsRemoved.length > 0) {
				if(len > 0){
					Data.videoExtendedsRemoved.reverse();
				}
				Data.videoExtendedsRemoved.forEach(function(item) {
					if(len > 0){
						Data.addVideoExtended(item, 'unshift');
					}
					else
						Data.addVideoExtended(item);
				});
				Data.videoExtendedsRemoved = [];
			}
			if(Data.videoNamesRemoved.length > 0) {
				if(len > 0){
					Data.videoNamesRemoved.reverse();
				}
				Data.videoNamesRemoved.forEach(function(item) {
					if(len > 0){
						Data.addVideoName(item, 'unshift');
					}
					else {
						//Data.videoNames.reverse();
						Data.addVideoName(item);
					}
				});
				Data.videoNamesRemoved = [];
			}
			if(Data.videoTypesRemoved.length > 0) {
				if(len > 0){
					Data.videoTypesRemoved.reverse();
				}
				Data.videoTypesRemoved.forEach(function(item) {
					if(len > 0){
						Data.addVideoType(item, 'unshift');
					}
					else {
						Data.addVideoType(item);
					}
				});
				Data.videoTypesRemoved = [];
			}
			if(Data.videoURLsRemoved.length > 0) {
				if(arguments.length > 0){
					Data.videoURLsRemoved.reverse();
				}
				Data.videoURLsRemoved.forEach(function(item) {
					if(arguments.length > 0)
						Data.addVideoURL(item, 'unshift');
					else {
						Data.addVideoURL(item);
					}
				});
				Data.videoURLsRemoved = [];
			}

}

Menu.SortData = function(arr) {
	arr.sort(function(a, b){
		 var index = a.search(/(s\d{2}e\d{2})/i);
		 a = a.slice(index+4, index+6);
				 index = b.search(/(s\d{2}e\d{2})/i);
		 b = b.slice(index+4, index+6);
		 return parseInt(a) - parseInt(b);
	});
}

Menu.SortDataNames = function(arr, qualities_length) {
	arr.sort(function(a, b){
		 var index = a.search(/(\(\d+\.\d+\s\w{2}\))/i);
		 a = a.split(' ');
		 a = a.slice(1);
		 a = a[0].replace(/[\(\)]/, '') + a[1].replace(/[\(\)]/, '');

		 index = b.search(/(\(\d+\.\d+\s\w{2}\))/i);
		 b = b.split(' ');
		 b = b.slice(1);
		 b = b[0].replace(/[\(\)]/, '') + b[1].replace(/[\(\)]/, '');;
		 if(a.search(/(GB)/) >= 0) {
			 a = parseFloat(a) * 1000;
		 }
		 if(b.search(/(GB)/) >= 0) {
			 b = parseFloat(b) * 1000;
		 }
		 return parseFloat(b) - parseFloat(a);
	});
	var super_arr = [];
	for(var i = 0; i < qualities_length; i++) {
		var len = arr.length;
		var split_arr = arr.splice(0, (len / (qualities_length - i)));
		split_arr.sort(function(a, b){
			 var index = a.search(/(s\d{2}e\d{2})/i);
			 a = a.slice(index+4, index+6);
					 index = b.search(/(s\d{2}e\d{2})/i);
			 b = b.slice(index+4, index+6);
			 return parseInt(a) - parseInt(b);
		});
		super_arr = super_arr.concat(split_arr);
	}
	return super_arr;
}

Menu.ChangePage = function()
{

	var quality_filter = false;

	if (this.quality_selected_index != -1 && this.qualities[this.quality_selected_index]){
		quality_filter = this.qualities[this.quality_selected_index];
	}

	// var menu_type = Data.getVideoType(Menu.GetItemId());
	// if(arguments.length > 0 && menu_type == 'play_link') {
	// 		this.current_size = 0;
	// 		if (!quality_filter) {
	// 			//Data.videoNames.reverse();
	// 			Menu.refillData('flag');
	// 		 } else {
	// 			Menu.refillData();
	// 		}
	// }

	var offs = this.page * this.size;
	var innerHtml = '';
	var n = offs;

	for( var i = 0; i < this.size || this.current_size < 9 && i < this.size; ++i ){
		if ( this.playlist[offs+i] ){

				var channelHtml = Channel.GetContainer((offs+i+1));
				var extended_info = Channel.getExtendedData((offs+i+1));

				if (quality_filter && extended_info.quality.indexOf(quality_filter) == -1){
						Data.removeVideoExtended((offs+i));
						Data.removeVideoName((offs+i));
						Data.removeVideoType((offs+i));
						Data.removeVideoURL((offs+i));
						channelHtml = '';
						i--;
				}

			  if(channelHtml) {
			     channelHtml = channelHtml.replace(/n\d+/, "n"+n++);
					 this.current_size++;
			  }

			 innerHtml += channelHtml;
		}
	}

	$('#'+this.divID).html(innerHtml);
}

Menu.FirstPage = function(){
	this.page = 0;
	this.pages = Math.ceil(Data.getVideoCount()/this.size);
	this.ChangePage();
	this.SelectFirst();
	this.SetPageHtml();

}

Menu.RefreshPage = function(){
	this.ChangePage();
}
Menu.PageNext = function()
{

	if ( this.page < this.pages - 1 ){
		++this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	} else {
		if (Data.getVideoType(Menu.GetItemId()) == 'folders'){
			Data.increaseExternalPage();
			Channel.nextExternalPage();
		}

	}
}
Menu.PagePrev = function()
{
	if ( this.page > 0 ){
		--this.page;
		this.ChangePage();
		this.SelectLast();
		this.SetPageHtml();
	} else {
		if (Data.getVideoType(Menu.GetItemId()) == 'folders'){
			if (Data.decreaseExternalPage()){
				Channel.prevExternalPage();
			}
		}

	}
}

Menu.SetPageHtml = function(){
	var menu_type = Data.getVideoType(Menu.GetItemId())
	if (menu_type == 'folders'){

		var page_num = 1;
		if (this.page == 0){
			page_num = Data.getExternalPage() * 2 + 1;
		} else {
			page_num = (Data.getExternalPage() + 1) * 2;
		}

		$('#page').html('Страница <span class="badge"> '+page_num+'</span>');
	} else {
		$('#page').html('Страница <span class="badge"> '+(this.page+1)+'</span> из <span class="badge">'+this.pages + '</span>');
	}

}

Menu.SetQualityHtml = function() {
	var menu_type = Data.getVideoType(Menu.GetItemId());
	if (menu_type == 'play_link') {
		var quality_array = Menu.GetQualities();
		if (quality_array.length > 0) {
			if (this.quality_selected_index < 0){
				$('.quality_name').text('All');
			} else {
				$('.quality_name').text(quality_array[this.quality_selected_index]);
			}

			$('.quality_block').css('display', 'table-cell');
		}
	} else {
		  $('.quality_block').css('display', 'none');
	}
}

Menu.SetBreadcrumbs = function(){
	var html = "";
	if (Channel.prev_data){
		$.each(Channel.prev_data, function(i, data){
			html += data.extended.menu_item_name + '\\';
		})
		var crumbs = '\\null\\null\\';
		if( html.indexOf(crumbs) >= 0) {
			html = $('#nav').html();
		}
	}
	$('#nav').html(html);
}

Menu.IsLastElement = function(){
	if ( this.page * this.size + this.pos < Data.getVideoCount()-1 ){
		return false;
	} else {
		return true;
	}
}

Menu.Next = function()
{
	if ( this.page * this.size + this.pos < Data.getVideoCount()-1 ){
		if ( this.pos < this.size-1 ){
			this.SelectNext();
		} else {
			this.PageNext();
		}
	} else {
		this.PageNext();
	}
}

Menu.Prev = function()
{
	if ( this.pos > 0 ){
		this.SelectPrev();
	} else {
		this.PagePrev();
	}
}

Menu.PageDown = function()
{
	if ( this.page < this.pages - 1 ){
		++this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	}
}

Menu.PageUp = function()
{
	if ( this.page > 0 ){
		--this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	}
}

Menu.SetItemId = function( id )
{
	if ( id > -1 && id < Data.getVideoCount() ){
		var nPage = Math.ceil((id+1) / this.size)-1;

		if (nPage < 0) nPage = 0;
		if (nPage > this.pages) nPage = this.pages;

		var nPos = id - (nPage * this.size);

		if ( nPage != this.page ){
			this.page = nPage;
			this.ChangePage();
			this.SetPageHtml();
		}
		//alert(nPos);
		if ( nPos != this.pos ){
			this.prev = this.pos;
			this.pos = nPos;
			this.Select();
		}
	}

}

Menu.GetItemId = function()
{
	return this.page * this.size + this.pos;
}

Menu.GetItem = function(){
	return this.playlist[this.GetItemId()];
}
