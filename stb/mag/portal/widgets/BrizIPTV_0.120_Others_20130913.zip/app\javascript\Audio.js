var Audio =
{
    plugin : null,
    mute : 0,
    NMUTE : 0,
    YMUTE : 1
    
}

Audio.init = function()
{
    var success = true;
    
    this.plugin = document.getElementById("pluginAudio");
    
    if (!this.plugin)
    {
        success = false;
    }

    return success;
}

Audio.setRelativeVolume = function(delta)
{
	if(Audio.mute == 0) {
		this.plugin.SetVolumeWithKey(delta);
		AudioInfo.Show( this.getVolume(), 1000 );
	}
    

}

Audio.getVolume = function()
{
    return this.plugin.GetVolume();
}

Audio.setMuteMode = function()
{
    if (this.mute != this.YMUTE)
    {
        Audio.plugin.SetSystemMute(true);
        AudioInfo.Show('MUTE');
        this.mute = this.YMUTE;
    }
}

Audio.noMuteMode = function()
{
    if (this.mute != this.NMUTE)
    {
        Audio.plugin.SetSystemMute(false);
        AudioInfo.Show( this.getVolume(), 1000 );
        this.mute = this.NMUTE;
    }
}

Audio.muteMode = function()
{
    switch (this.mute)
    {
        case this.NMUTE:
            this.setMuteMode();
            break;
            
        case this.YMUTE:
            this.noMuteMode();
            break;
            
        default:
            alert("ERROR: unexpected mode in muteMode");
            break;
    }
}
