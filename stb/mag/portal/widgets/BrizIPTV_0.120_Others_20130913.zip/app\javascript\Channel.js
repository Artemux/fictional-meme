var Channel = 
{
		
	genreList : ["favorites","", "movies", "news", "educations", "sports", "childrens", "musics", "hdtv", "russia", "ukraine", "odessa", "specials", "shows"],

	genresRus : [	{'Name':"Избранные", 'Callback':"Favorites.Load()"},
	             	{'Name':"Все каналы"},
		            {'Name': "Фильмовые"},
					{'Name': "Новостные"},
					{'Name': "Познавательные"},
					{'Name': "Спортивные"},
					{'Name': "Детские"},
					{'Name': "Музыкальные"},
					{'Name': "HDTV"},
					{'Name': "Российские"},
					{'Name': "Украинские"},
					{'Name': "Одесские"},
					{'Name': "International"},
					{'Name': "Развлекательные"} ],	
		
	delay : 350,
	delayTm : null	
}

Channel.Play = function(){
	
	$('#chanInfo .chan-name').html(Data.getVideoName(Menu.GetItemId()));
	$('#chanInfo .chan-num .badge').html(Menu.GetItemId()+1);
	
	this.ShowProgram();
	
	var checkUdp = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
	var url = Data.getVideoURL(Menu.GetItemId());
	if (checkUdp.test(url)){
		url = 'udp://@' + url;
	}
	Player.setVideoURL(url);
	
	if ( this.delayTm != null){
		clearTimeout(this.delayTm);
		this.delayTm = null;
	}
	
	this.delayTm = setTimeout("Player.playVideo()", this.delay)
	
}

Channel.Stop = function(){
	Player.stopVideo();
}

Channel.GetContainer = function( id ){
	var itemID = id - 1;
	return '<div id="n'+itemID+'" class="unselected">&nbsp;<span class="badge">'+id+'</span> '+Data.getVideoName(itemID)+'</div>';
} 

Channel.ShowCurrentProgram = function(){
	if ( Data.getVideoCount() > 0 && Settings.epgEnable == true){
		$.ajax({
	        type: "POST",
	        url: Settings.epgURL,
			dataType: "json",
	        data: "chanID="+Data.getVideoDescription(Menu.GetItemId())+'&method=current',
			beforeSend: function(){
				var html = '<div class="loading"><img src="app/images/ajax-loader.gif" alt=""></img></div>';
				$('.selected').append(html);
			},
	        success: function(msg){
				$('.loading').remove();
				var html = 	'<div class="current-program">'+
								'<div class="image"> <img src="app/images/current-play.png" alt="" /></div>' +
								'<div class="end">' + msg.end + '</div>' +
								'<div class="program">' + msg.text + '</div>' +
							'</div>'
				$('.selected').append(html);    
	        },
	        error : function(jqXHR, textStatus) {
	        	$('.loading').remove();
			}
    	});
	}
}

Channel.ShowProgram = function(){
	if ( Data.getVideoCount() > 0 && Settings.epgEnable == true){
		$.ajax({
	        type: "POST",
	        url: Settings.epgURL,
			dataType: "json",
	        data: "simple="+Data.getVideoDescription(Menu.GetItemId()),
			beforeSend: function(){
				//var html = '<img src="app/images/ajax-loader.gif" alt=""></img>';
				//$('#chan-footer').html(html);
			},
	        success: function(json){
	        	var html = '';
	        	if (json != 0){
	        		$.each( json, function(index, item){
	        			html += '<div class="epg"> <div class="time">'+item.time.substring(0, item.time.length-3)+'</div><div class="program">'+item.program+'</div> </div>';
	        		});
	        	} else {
	        		html = 'Нет программы телепередач для выбранного канала';
	        	}
	        	
	        	$('#chan-footer').html(html); 
	        }
    	});
	}
}