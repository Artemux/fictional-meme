var Data =
{
    videoNames : [ ],
    videoURLs : [ ],
    videoDescriptions : [ ],
    videoImages : []
}

Data.setVideoNames = function(list)
{
    this.videoNames = list;
}

Data.setVideoURLs = function(list)
{
    this.videoURLs = list;
}

Data.setVideoDescriptions = function(list)
{
    this.videoDescriptions = list;
}

Data.setVideoImages = function(list){
	this.videoImages = list;
}

Data.getVideoURL = function(index)
{
    var url = this.videoURLs[index];
    
    if (url)    // Check for undefined entry (outside of valid array)
    {
        return url;
    }
    else
    {
        return null;
    }
}

Data.getVideoImage = function(index)
{
    var image = this.videoImages[index];
    
    if (image)    // Check for undefined entry (outside of valid array)
    {
        return image;
    }
    else
    {
        return "http://www.briz.ua/images/users/no-logo.jpg";
    }
}

Data.getVideoName = function(index)
{
    var name = this.videoNames[index];
    
    if (name)    // Check for undefined entry (outside of valid array)
    {
        return name;
    }
    else
    {
        return null;
    }
}

Data.getVideoCount = function()
{
    return this.videoURLs.length;
}

Data.getVideoNames = function()
{
    return this.videoNames;
}

Data.getVideoDescription = function(index)
{
    var description = this.videoDescriptions[index];
    
    if (description)    // Check for undefined entry (outside of valid array)
    {
        return description;
    }
    else
    {
        return "No description";
    }
}
