var Favorites = {
	data : [],
	fileName : 'favorites.json',

}

Favorites.Init = function() {

	if (!Storage.IsFile(this.fileName)) {
		Storage.Save(this.fileName, '[]');
	}
	
	this.Load();
	
}

Favorites.Show = function() {

	Server.createVideoList(this.data);

}

Favorites.Load = function() {
	
	var content = Storage.Load(this.fileName);
	
	this.data = eval(content);
	
	this.Show();

}

Favorites.Save = function() {
	
	Storage.Save(this.fileName,JSON.stringify(this.data));

}

Favorites.IsExist = function( name ){
	
	var stat = false;
	
	$.each(this.data, function(index, item){
		
		if ( item[1] == name ){
			stat = index;
		}
		
	});
	
	return stat;
	
}

Favorites.Add = function() {

	var id = Menu.GetItemId();
	alert(this.data);
	if (typeof(id) == 'number' && id > -1) {
		
		var check = this.IsExist(Data.getVideoName(id));
		
		if (check === false){
			
			var chanData = [ Data.getVideoURL(id), Data.getVideoName(id),
			                 Data.getVideoDescription(id), Data.getVideoImage(id), ];

			this.data.push(chanData);
			Popup.Show('Канал добавлен в избранное', 1000);
		} else {
			alert(check);
			this.data.splice(check, 1);
			Popup.Show('Канал удален из избранного', 1000);
		}
		
		this.Save();
		
	}

}

Favorites.Delete = function(id) {

}
