var widgetAPI = new Common.API.Widget();
var tvKey = new Common.API.TVKeyValue();
var pluginAPI = new Common.API.Plugin();

var Popup = new StatusWindow();
var AudioInfo = new StatusWindow();
var ServiceMenu = new StatusWindow();
var ChannelMenu = new StatusWindow();
var ChannelInfo = new StatusWindow();

var Genre = new MenuExtended();
var GenreMenu = new StatusWindow();

var StartupMenu = new MenuExtended();
var StartupWindow = new StatusWindow();

var Main = {

};

Main.onLoad = function() {
	
	_g_ime.keySet = 'qwerty';
	
	Menu.init('chan-list');
	Popup.init('Popup','popup', true);
	AudioInfo.init('AudioInfo','audio', true);
	ChannelMenu.init('ChannelMenu','main', false);
	ServiceMenu.init('ServiceMenu','footer', false);
	ChannelInfo.init('ChannelInfo','chanInfo', false);
	
	GenreMenu.init('GenreMenu', 'menu-extended', true);
	Genre.init('menu-extended');
	Genre.SetItems(Channel.genresRus);
	                       	
	if (Server.init() && Player.init() && Settings.init() && Audio.init() && Storage.init()) {
		
		Favorites.Init();
		
		var StartupMenuData = [];
		
		if (Storage.IsFile(Server.playlistFile)){
			StartupMenuData.push({'Name':"Сохраненный плейлист", 'Callback': 'Main.StartApp("file")'});
		}
		
		StartupMenuData.push({'Name':"От провайдера", 'Callback': 'Main.StartApp("json")'});
		StartupMenuData.push({'Name':"Указать адрес плейлиста", 'Callback': 'Main.PlaylistInput()'});
				
		StartupMenu.init('menu-startup');
		StartupMenu.SetItems(StartupMenuData);
		StartupMenu.Render();
		StartupWindow.init('StartupWindow', 'startup-window', true);
		StartupWindow.Show('', 'always');
		
		Server.dataReceivedCallback = function() {
			/* Use video information when it has arrived */
			ChannelMenu.Show('', 5000);
			Menu.SetList(Data.getVideoNames());
			Menu.Render();
			Channel.Play();
		}
		
		$('#mac').html('version 1.0001 Mac is:'+networkPlugin.GetMAC());

		// Enable key event processing
		this.enableKeys();

		widgetAPI.sendReadyEvent();
	} else {
		alert("Failed to initialise");
	}

};

Main.StartApp = function( type ){
	
	StartupWindow.Hide();
	
	ServiceMenu.Show('', 5000);
	
	// Start retrieving data from server
	
	Server.fetchVideoList(type); /* Request video information from server */
	
}

Main.onUnload = function() {
	Player.deinit();
};

Main.PlaylistInput = function(){
	$('#startup-window').append('<div class="inputBlock"><input id="inputUrl" type="text" value="http://www.briz.ua/images/user/File/smarttv.m3u" size="50" /></div>');
	ime = new IMEShell("inputUrl");
	ime.setKeypadPos(200, 120);
	ime.setQWERTYPos(200, 180);
    ime.setEnterFunc(Main.onEnter);
    ime.setKeySetFunc('qwerty');
    ime.setKeyFunc(tvKey.KEY_EXIT, function(keyCode) { widgetAPI.sendExitEvent(); return false; } );
    
    document.getElementById("inputUrl").focus();
}
Main.onEnter = function(string){
	if ( string.length > 6){
		Server.fetchVideoListM3U(string);
		StartupWindow.Hide();
	}
	ime = null;
	Main.enableKeys();
	document.getElementById("inputUrl").blur();
	$('.inputBlock').remove();
}
Main.enableKeys = function() {
	document.getElementById("anchor").focus();
};

Main.keyDown = function() {
	var keyCode = event.keyCode;

	switch (keyCode) {
		case tvKey.KEY_EXIT:
		case tvKey.KEY_RETURN:
		case tvKey.KEY_PANEL_RETURN:

			if (Menu.IsKeypress()){
				Menu.KeypressBack();
			} else {
				if ( GenreMenu.IsShow() ){
					GenreMenu.Hide();
				} else {
					if ( ChannelMenu.IsShow() ){
						ChannelMenu.Hide();
						ServiceMenu.Hide();
					} else {
						if ( !StartupWindow.IsShow() ){
							StartupWindow.Show('', 'always');
						} else {
							StartupWindow.Hide();
						}
					}
				}		
			}
			
			break;
		case 35: //tvKey.KEY_EMPTY
			if (Menu.IsKeypress()){
				Menu.KeypressBack();
			}
			break;
		
		case tvKey.KEY_BLUE:
			Favorites.Add();
			//Server.fetchVideoListM3U('http://www.briz.ua/images/user/File/smarttv.m3u');
			break;
		case tvKey.KEY_YELLOW:
			Favorites.Load();
			break;
		case tvKey.KEY_GREEN:
			
			Storage.Delete(Server.playlistFile);
			Storage.Delete(Favorites.fileName);
		break;
			
		case tvKey.KEY_RED:
			if ( Server.playlistType == 'json' ){
				if ( GenreMenu.IsShow() ){
					GenreMenu.Hide();
				} else {
					Genre.Render();
					GenreMenu.Show('', 3000);
				}
			} else {
				Main.StartApp("file");
			}
			
			
		break;
		
		case tvKey.KEY_LEFT:
			alert("LEFT");
			if ( ChannelMenu.IsShow() ){
				ChannelMenu.Show('', 3000);
				ServiceMenu.Show('', 3000);
				Menu.PageUp();
			}
			
			break;
			
		case tvKey.KEY_RIGHT:
			alert("RIGHT");
			if ( ChannelMenu.IsShow() ){
				ChannelMenu.Show('', 3000);
				ServiceMenu.Show('', 3000);
				Menu.PageDown();
			}
			
			break;
			
		case tvKey.KEY_UP:
			if (GenreMenu.IsShow()){
				 Genre.Prev();
				 GenreMenu.Show('', 3000);
			 } else if (StartupWindow.IsShow()){
				 StartupMenu.Prev();
			 } else {
				Menu.Prev();
				if ( ChannelMenu.IsShow() ){
					ChannelMenu.Show('', 3000);
					ServiceMenu.Show('', 3000);
				} else {
					Channel.Play();
				}
			}
			
			break;
			
		case tvKey.KEY_DOWN:
			 if (GenreMenu.IsShow()){
				 Genre.Next();
				 GenreMenu.Show('', 3000);
			 } else if (StartupWindow.IsShow()){
				 StartupMenu.Next();
			 } else {
				 Menu.Next();
				 if ( ChannelMenu.IsShow() ){
					 ChannelMenu.Show('', 3000);
					 ServiceMenu.Show('', 3000);
				 } else {
					 Channel.Play();
				 }
			 }
			
			break;
			
		case tvKey.KEY_CH_UP:
		case tvKey.KEY_PANEL_CH_UP:
			Menu.Next();
			if ( ChannelMenu.IsShow() ){
				ChannelMenu.Show('', 3000);
				ServiceMenu.Show('', 3000);
			} else {
				Channel.Play();
			}
			break;
			
		case tvKey.KEY_CH_DOWN:
		case tvKey.KEY_PANEL_CH_DOWN:
			Menu.Prev();
			if ( ChannelMenu.IsShow() ){
				ChannelMenu.Show('', 3000);
				ServiceMenu.Show('', 3000);
			} else {
				Channel.Play();
			}
			break;
		case tvKey.KEY_PLAY:
			Channel.Play();
			break;
			
		case tvKey.KEY_STOP:
			Channel.Stop();
			ChannelMenu.Show();
			ServiceMenu.Show();
		break;
		
		case tvKey.KEY_ENTER:
		case tvKey.KEY_PANEL_ENTER:
			if (Menu.IsKeypress()){
				Menu.DoSwitch();
			} else {
				if (GenreMenu.IsShow()){
					if ( Genre.IsAction() ){
						Genre.Action();
					} else {
						Server.fetchVideoListGenre(Channel.genreList[Genre.GetItemId()]);
					}
					
					GenreMenu.Hide();
				} else if (StartupWindow.IsShow()){
					StartupMenu.Action();
				} else { 
					if ( ChannelMenu.IsShow() ){
						ChannelMenu.Hide();
						ServiceMenu.Hide();
						Channel.Play();
					} else {
						ChannelMenu.Show('', 3000);
						ServiceMenu.Show('', 3000);
					}
				}
			}
			break;
			
		case tvKey.KEY_VOL_UP:
        case tvKey.KEY_PANEL_VOL_UP:
            alert("VOL_UP");
                Audio.setRelativeVolume(0);
            break;
            
        case tvKey.KEY_VOL_DOWN:
        case tvKey.KEY_PANEL_VOL_DOWN:
            alert("VOL_DOWN");
                Audio.setRelativeVolume(1);
            break;	
        case tvKey.KEY_INFO:
        		if (ChannelInfo.IsShow()){
        			ChannelInfo.Hide();
        		} else {
        			ChannelInfo.Show();
        		}
        	break;
        	
        case tvKey.KEY_MENU:
        		if ( ChannelMenu.IsShow() ){
        			ChannelMenu.Hide();
					ServiceMenu.Hide();
        		} else {
        			ChannelMenu.Show();
					ServiceMenu.Show();
        		}
        	break;
        
        case tvKey.KEY_MUTE:
            alert("MUTE");
            Audio.muteMode();
            break;
		case tvKey.KEY_1:
			Menu.Keypress(1);
			break;
		case tvKey.KEY_2:
			Menu.Keypress(2);
			break;
		case tvKey.KEY_3:
			Menu.Keypress(3);
			break;
		case tvKey.KEY_4:
			Menu.Keypress(4);
			break;
		case tvKey.KEY_5:
			Menu.Keypress(5);
			break;
		case tvKey.KEY_6:
			Menu.Keypress(6);
			break;
		case tvKey.KEY_7:
			Menu.Keypress(7);
			break;
		case tvKey.KEY_8:
			Menu.Keypress(8);
			break;
		case tvKey.KEY_9:
			Menu.Keypress(9);
			break;
		case tvKey.KEY_0:
			Menu.Keypress(0);
		break;
		default:
			alert("Unhandled key");
			break;
		}
};
