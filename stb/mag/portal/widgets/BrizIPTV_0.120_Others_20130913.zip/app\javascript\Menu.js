var Menu =
{
	
	divID : null,
    firstElID : 1,
    pos: -1,
    prev: -1,
    page : 0,
    pages : 1,
    elID : 0,
    size : 12,
    
    delay : 300,
	delayTm : null,
	chanDelay: 3000,
	chanTm : null,
	chanStr : '',
	
    playlist : null,
    
    selectedClass : 'selected',
    unSelectedClass : 'unselected'
	
}

Menu.init = function( divID ){
	
	this.divID = divID;
	
}

Menu.Render = function(){
	this.FirstPage();
	this.SetPageHtml();
	this.SelectFirst();
}

Menu.DoSwitch = function()
{
	if ( this.chanStr ){
		var chanNo = parseInt(this.chanStr);
		if ( this.playlist[chanNo-1] ){
			this.prev = this.pos;
			this.pos = chanNo-1;
			this.SetItemId(chanNo-1);
			Channel.Play();
		}
		this.chanStr = "";
	}
	this.chanTm = null;
}

Menu.IsKeypress = function(){
	if (this.chanStr.length > 0){
		return true;
	} else {
		return false;
	}
}

Menu.KeypressBack = function( )
{
	if ( this.chanStr.length > 0){
		this.chanStr = this.chanStr.substring(0, this.chanStr.length - 1);
		if ( this.chanTm != null ){
			clearTimeout(this.chanTm);
		}
		this.chanTm = setTimeout("Menu.DoSwitch()", this.chanDelay);
		Popup.Show(this.chanStr, this.chanDelay);
	} else {
		Popup.Hide();
	}

}

Menu.Keypress = function( keyStr )
{
	this.chanStr += keyStr;
	if ( this.chanTm != null ){
		clearTimeout(this.chanTm);
	}
	this.chanTm = setTimeout("Menu.DoSwitch()", this.chanDelay);
	Popup.Show(this.chanStr, this.chanDelay);
}

Menu.Select = function()
{
	$(".current-program").remove();
	
	if ( this.prev > -1 ){
		var prevEl = this.page * this.size + this.prev;
		$('#n'+prevEl).attr('class', this.unSelectedClass);
	}
	var curEl = this.page * this.size + this.pos;
	$('#n'+curEl).attr('class', this.selectedClass);
	
	if ( this.delayTm != null ){
		clearTimeout(this.delayTm);
	}
	
	this.delayTm = eval("setTimeout(function(){Channel.ShowCurrentProgram();},"+this.delay+")");
}

Menu.SetList = function( list ){
	
	this.playlist = list;
	
	if ( Data.getVideoCount() > this.size ){
		this.pages = Math.ceil(Data.getVideoCount()/this.size);
	}
	
}

Menu.SelectFirst = function()
{
	this.prev = this.pos;
	this.pos = 0;
	this.Select();
}

Menu.SelectLast = function()
{
	this.prev = this.pos;
	this.pos = this.size - 1;
	this.Select();
}

Menu.SelectNext = function()
{
	this.prev = this.pos;
	++this.pos;
	this.Select();
}

Menu.SelectPrev = function()
{
	this.prev = this.pos;
	--this.pos;
	this.Select();
}

Menu.ChangePage = function()
{
	var offs = this.page * this.size;
	var innerHtml = '';
	for( var i = 0; i < this.size; ++i ){
		if ( this.playlist[offs+i] ){
			 innerHtml += Channel.GetContainer((offs+i+1));
		}
	}
	
	$('#'+this.divID).html(innerHtml);
}

Menu.FirstPage = function(){
	this.page = 0;
	this.pages = Math.ceil(Data.getVideoCount()/this.size);
	this.ChangePage();
	this.SelectFirst();
	this.SetPageHtml();
    
}

Menu.RefreshPage = function(){
	this.ChangePage();
}
Menu.PageNext = function()
{
	if ( this.page < this.pages - 1 ){
		++this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	}
}
Menu.PagePrev = function()
{
	if ( this.page > 0 ){
		--this.page;
		this.ChangePage();
		this.SelectLast();
		this.SetPageHtml();
	}
}

Menu.SetPageHtml = function(){
	$('#page').html('Страница <span class="badge"> '+(this.page+1)+'</span> из <span class="badge">'+this.pages + '</span>');
}

Menu.Next = function()
{
	if ( this.page * this.size + this.pos < Data.getVideoCount()-1 ){
		if ( this.pos < this.size-1 ){
			this.SelectNext();
		} else {
			this.PageNext();
		}
	}
}

Menu.Prev = function()
{
	if ( this.pos > 0 ){
		this.SelectPrev();
	} else {
		this.PagePrev();
	}
}

Menu.PageDown = function()
{
	if ( this.page < this.pages - 1 ){
		++this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	}
}

Menu.PageUp = function()
{
	if ( this.page > 0 ){
		--this.page;
		this.ChangePage();
		this.SelectFirst();
		this.SetPageHtml();
	}
}

Menu.SetItemId = function( id )
{
	if ( id > -1 && id < Data.getVideoCount() ){
		var nPage = Math.ceil((id+1) / this.size)-1;
		
		if (nPage < 0) nPage = 0;
		if (nPage > this.pages) nPage = this.pages;
		
		var nPos = id - (nPage * this.size);
		
		if ( nPage != this.page ){
			this.page = nPage;
			this.ChangePage();
			this.SetPageHtml();
		}
		//alert(nPos);
		if ( nPos != this.pos ){
			this.prev = this.pos;
			this.pos = nPos;
			this.Select();
		}
	}

}

Menu.GetItemId = function()
{
	return this.page * this.size + this.pos;
}

Menu.GetItem = function(){
	return this.playlist[this.GetItemId()];
}
