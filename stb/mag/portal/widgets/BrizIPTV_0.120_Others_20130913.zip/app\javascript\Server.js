var Server = {
	playlistType : 'file',	
	playlistFile : 'playlist.m3u',	
	/* Callback function to be set by client */
	dataReceivedCallback : null,

}

Server.init = function() {
	return true;
}

Server.fetchVideoList = function(type) {

	Popup.Show('Loading channels...', 'always');
	
	this.playlistType = type;
	
	if (type == 'json') {
		$.ajax({
			dataType : "json",
			url : Settings.chanURL,
			data : 'mac=00-1a-79-01-bb-0c&g=:172.18.12.8',
			success : function(json) {

				Server.createVideoList(json);
			}
		});
	} else if ( type == 'file' ){
		var playlist = Storage.Load(this.playlistFile);
		Server.ParseM3U(playlist);
	}

}

Server.fetchVideoListM3U = function( url ){
	Popup.Show('Loading channels...', 'always');
	$.ajax({
		dataType : "html",
		url : url,
		success : function(playlist) {
			Popup.Show('Save data...', 'always');
			Storage.Save(Server.playlistFile, playlist);
			Server.ParseM3U(playlist);
		},
		error : function(jqXHR, textStatus) {
			Popup.Show('Error', 'always');
		}
	});
}

Server.ParseM3U = function( playlist ){
	Popup.Show('Parsing...', 'always');
	var chanReg = /#EXTINF:(\d*),(.*)/;
	
	var cleanArr = [];
	var items = [];
	var num = 1;
	var arr = playlist.split(/(\n|\r|\n\r|\r\n)/);
	
	for ( var i = 0; i < arr.length; i++){
		var str = arr[i].toUpperCase();
		if ( str != "#EXTM3U" && str.length > 2){
			cleanArr.push(arr[i]);
		}
	}
	
	for ( var i = 0; i < cleanArr.length; i++){
			var chanParse = chanReg.exec(cleanArr[i]);
			if (chanParse){
				i++;
				Popup.Show('Parsing...' + num, 'always');
				items.push( new Array(cleanArr[i], chanParse[2], chanParse[1], ''));
				num++;
			}
	}
	
	if (items.length > 0){
		Server.createVideoList(items);
	} else {
		Popup.Show('Empty List', 3000);
	}
}

Server.fetchVideoListGenre = function(genre) {

	Popup.Show('Loading channels...', 'always');
	$.ajax({
		dataType : "json",
		url : Settings.chanURL,
		data : 'mac=00-1a-79-01-bb-0c&g=' + genre + ':172.18.12.8',
		success : function(json) {
			Server.createVideoList(json);
		}
	});

}

Server.createVideoList = function(items) {
	Popup.Show('Preparing...', 'always');
	var videoNames = [];
	var videoURLs = [];
	var videoDescriptions = [];
	var videoImages = [];

	$.each(items, function(index, item) {
		var linkElement = item[0];
		var titleElement = item[1];
		var descriptionElement = item[2];
		var imageElement = item[3];

		if (titleElement && descriptionElement && linkElement) {
			videoNames[index] = titleElement;
			videoURLs[index] = linkElement;
			videoDescriptions[index] = descriptionElement;
			videoImages[index] = imageElement;
		}

	});

	Data.setVideoNames(videoNames);
	Data.setVideoURLs(videoURLs);
	Data.setVideoDescriptions(videoDescriptions);
	Data.setVideoImages(videoImages);
	Popup.Show('Complete!', 1000);
	if (this.dataReceivedCallback) {
		this.dataReceivedCallback();
	}
}
