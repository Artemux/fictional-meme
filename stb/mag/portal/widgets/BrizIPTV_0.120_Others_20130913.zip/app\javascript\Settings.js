var Settings = {
		
		chanURL : "http://192.168.1.101/zyxel/stb.php",
		epgURL : "http://briz.ua/stb/mag/portal/programs/epg/index.php",
		
		
		epgEnable : true,
		
	
}

Settings.init = function(){
	
	// управление анимацией
	$.fx.off=0;
	
	return true;
	
}