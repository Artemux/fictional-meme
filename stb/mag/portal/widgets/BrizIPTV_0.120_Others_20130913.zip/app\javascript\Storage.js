var Storage = {

	fileSystemObj : null,

	callback : null,

}

Storage.init = function() {

	this.fileSystemObj = new FileSystem();

	if (this.fileSystemObj) {
		var bValid = this.fileSystemObj.isValidCommonPath(curWidget.id);

		if (bValid == 0) {
			var cResult = this.fileSystemObj.createCommonDir(curWidget.id);
			if (cResult) {
				alert("<-----------Common Dir Created----------->");
				return true;
			} else {
				alert("<-----------Unable to create Common Dir----------->");
			}
		} else if (bValid == 1) {
			alert("<-----------Directory already exists----------->");
			return true;
		}

	}

	return false;

}

Storage.Save = function( file, str ) {

	var jsFileObj = this.fileSystemObj.openCommonFile(file, "w");
	if (jsFileObj) {
		alert("Writing to File-----------> "+file);
		jsFileObj.writeLine(str);
		alert("Done Writing----------->" + file);
		this.fileSystemObj.closeCommonFile(jsFileObj);

		return true;
	}

	return false;

};

Storage.Load = function( file ) {

	var jsFileObj = this.fileSystemObj.openCommonFile(file, "r");
	alert("Reading from File-----------> "+file);
	if (jsFileObj) {
		var readresult = jsFileObj.readAll();
		alert("Done Reading-----------> "+file);
		this.fileSystemObj.closeCommonFile(jsFileObj);
		if ( readresult ){
			return readresult;
		}
		
	}

	return false;

};

Storage.Delete = function( file ) {
	
	 var eResult = this.fileSystemObj.deleteCommonFile(file);
    if(eResult)
    {
       alert("Deleted-----------> "+file);
    }
    else
    {
       alert("Unable to Delete File-----------> "+file);
    }
	
};

Storage.IsFile = function( file ) {

	var jsFileObj = this.fileSystemObj.openCommonFile(file, "r");
	alert("Reading from File-----------> "+file);
	alert(jsFileObj)
	if (jsFileObj) {
		var readresult = jsFileObj.readAll();
		alert("Done Reading-----------> "+file);
		this.fileSystemObj.closeCommonFile(jsFileObj);
		if (readresult.length > 1) {
			return true;
		}
	}

	return false;
}