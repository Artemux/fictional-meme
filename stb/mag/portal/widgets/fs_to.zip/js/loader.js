alert(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> LOADER <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

var page = window.location.pathname.split("/").pop();

var version = '';
var widgetPath = '';

// Servers
var activeServer = null;
var servers = {
	'SERVER_1' : {
		'files' : 'files.wiget.pp.ua',
		'proxy' : 'fs.wiget.pp.ua'
	},
	'SERVER_2' : {
		'files' : 'filesr1.wiget.pp.ua',
		'proxy' : 'fsr1.wiget.pp.ua'
	}
};

// Check server status
function checkServerStatus(domain) 
{
	var ret = null;

	if(domain != undefined && domain != '') {
		try {
			var xhr = new XMLHttpRequest();
			xhr.open("GET", "http://"+domain+"/index.html", false);
			xhr.onreadystatechange = function () {
				if (xhr.readyState == 4) {
					ret = xhr.status;
				}
			};
			xhr.send();
		} catch(e) {
			alert(e);
		}
	}
	
	return ret;
}

// Get version and active server
var xhr = new XMLHttpRequest();
xhr.open("GET", "config.xml", false);
xhr.onreadystatechange = function () {
	if (xhr.readyState == 4 && xhr.status == 200)
	{
		var xml = xhr.responseText;
		var myRe = new RegExp("<ver>(.*)</ver>","igm");
		if (ver = myRe.exec(xml)) {
			
			version = ver[1];
			
			for(var index in servers) { 
				if(servers[index]['files'] != undefined && servers[index]['proxy'] != undefined) {
					var fileServerStatus = checkServerStatus(servers[index]['files']);
					var proxyServerStatus = checkServerStatus(servers[index]['proxy']);

					if(fileServerStatus == 200 && proxyServerStatus == 200){
						activeServer = index;
						break;
					}
				}
			}
			
			if(version != '') {
				if(activeServer != null) {
					widgetPath = 'http://' + servers[activeServer]['files'] + '/fs_server/' + version.replace(/\./g,'_') + '/';
				} else {
					widgetPath = null;
				}
			}
		}
	}
};
xhr.send();

if(activeServer != null) {
	alert(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + activeServer + " <<<<<<<<<<<<<<<<<<<<");
} else {
	alert(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ALL SERVERS OFFLINE <<<<<<<<<<<<<<<<<<<<<<<");
}

var head = document.getElementsByTagName('head').item(0);
var js = document.createElement('script');
js.setAttribute('language', 'javascript');
js.setAttribute('type', 'text/javascript');

if(activeServer != null) {
	js.setAttribute('src', widgetPath + 'script/Loader.js');
} else {
	if(page == 'index.html') {
		js.setAttribute('src', 'js/Main.js');
	}
	else if(page == 'settings.html') {
		js.setAttribute('src', 'js/Settings.js');
	}
}

head.appendChild(js);